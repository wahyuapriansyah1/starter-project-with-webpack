import { addStory } from '../../data/api';

class AddPresenter {
  constructor({ showToast, redirectHome }) {
    this.showToast = showToast;
    this.redirectHome = redirectHome;
  }

  async submitForm({ name, description, photo, lat, lng }) {
    if (!name || !description || !photo || !lat || !lng) {
      this.showToast('Semua kolom wajib diisi dan lokasi harus dipilih.');
      return;
    }
    this.showToast('Mengirim data...');
    try {
      const result = await addStory({ description: `${name} - ${description}`, photo, lat, lon: lng });
      if (result.error) {
        this.showToast(result.message || 'Gagal menambah kuliner.');
      } else {
        this.showToast('Berhasil menambah kuliner!');
        setTimeout(() => { this.redirectHome(); }, 1200);
      }
    } catch (err) {
      this.showToast('Terjadi kesalahan jaringan.');
    }
  }
}

export default AddPresenter;
