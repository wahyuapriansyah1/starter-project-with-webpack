import { getStories } from '../../data/api';

class HomePresenter {
  constructor(view) {
    this.view = view;
  }

  async loadStories() {
    this.view.showLoading();
    try {
      const data = await getStories();
      if (data.error) {
        this.view.showError(data.message);
        return;
      }
      if (!data.listStory || data.listStory.length === 0) {
        this.view.showEmpty();
        return;
      }
      this.view.showStories(data.listStory);
    } catch (err) {
      this.view.showError('Terjadi kesalahan saat memuat data.');
    }
  }
}

export default HomePresenter;
